from django.db import models

class CandidateTestCategoryModel(models.Model):
    name = models.CharField(max_length=500, null=True)
    category_time = models.TimeField(null=True)
    category_amount = models.FloatField(null=True)

class CandidateTestModel(models.Model):
    category = models.ForeignKey(CandidateTestCategoryModel, on_delete=models.SET_NULL, null=True)
    book_date = models.DateField()
    book_time = models.TimeField()
    candidate_name = models.CharField(max_length=500)
    date_of_birth = models.DateField()
    passport_no = models.CharField(max_length=500)
    contact_number = models.BigIntegerField()
    whatsapp_number = models.BigIntegerField()
    email = models.CharField(max_length=500, null=True)
    agent_code = models.CharField(max_length=500, null=True)
    certificate = models.FileField(upload_to='Candidates_Certificates/', null=True)