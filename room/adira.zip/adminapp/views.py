from django.shortcuts import render, redirect
from django.views import View
from candidatetest.models import CandidateTestModel
from django.http import HttpResponse, JsonResponse
import fitz, os, uuid
from adira import settings
from io import BytesIO
from django.core.files.uploadedfile import InMemoryUploadedFile

class AdminDashboard(View):
    template_name = 'applied-candidate-list.html'
    def get(self, request):
        candidates = CandidateTestModel.objects.all()
        datas = {'candidates': candidates}
        return render(request, self.template_name, context=datas)

class CandidateReportView(View):
    template_name = 'candidate-report.html'
    def get(self, request, id):
        candidate = CandidateTestModel.objects.get(id=id)
        datas = {
            'candidate': candidate,
        }
        return render(request, self.template_name, context=datas)