from django.urls import path
from adminapp import views

urlpatterns = [
    path('', views.AdminDashboard.as_view()),
    path('candidate-report/<int:id>', views.CandidateReportView.as_view()),
]